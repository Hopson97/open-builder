
-- Load up structure gen stuff
dofile(path .. "world/common_tree_gen.lua")
dofile(path .. "world/common_cactus_gen.lua")

-- Register biomes to the game
dofile(path .. "world/grassland_biome.lua")
dofile(path .. "world/desert_biome.lua")
